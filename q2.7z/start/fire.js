console.log('Fire started!')
