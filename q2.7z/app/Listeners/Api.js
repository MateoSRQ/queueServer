'use strict'

const Api = exports = module.exports = {}

Api.method = async () => {
}
